const int btn1 = 12;
const int btn2 = 13;
const int btn3 = 14;
const int greenLed = 15;
const int redLed = 16; 
const int length = 5;
int code[length] = {1,3,2,3,1};
int enteredcode[length];
int presscount = 0;
int tries = 0;

void setup(){
  Serial.begin(115200);

  pinMode(btn1, INPUT_PULLUP);
  pinMode(btn2, INPUT_PULLUP);
  pinMode(btn3, INPUT_PULLUP);
  pinMode(greenLed, OUTPUT);
  pinMode(redLed, OUTPUT);

  digitalWrite(redLed, HIGH);
  digitalWrite(greenLed, LOW);
  Serial.println("press the buttons to match the code ");

}

void loop(){
  if(digitalRead(btn1) == LOW){
    pressregister(1);
    waitforrelease(btn1);
  }else if(digitalRead(btn2) == LOW){
    pressregister(2);
    waitforrelease(btn2);
  }else if(digitalRead(btn3) == LOW){
    pressregister(3);
    waitforrelease(btn3);
  }
}

void pressregister(int pressedbutton){

  Serial.print("pressed : ");
  Serial.println(pressedbutton);

  enteredcode[presscount] = pressedbutton;
  presscount++;

  if(presscount == length){
    checkpass();
  }
}

void checkpass(){

  bool iscorrect = true;
  for(int i = 0 ; i < length ; i++){
    if(code[i] != enteredcode[i]){
      iscorrect = false;
    }
  }

  if(iscorrect){
    Serial.println("entered sequence is matched");
    Serial.println("access granted");
    digitalWrite(redLed, LOW);
    digitalWrite(greenLed, HIGH);
    delay(4000);
    digitalWrite(greenLed, LOW);
  }else{
    Serial.println("sequence did not match");
    Serial.println("access denied");
    digitalWrite(redLed, LOW);
    delay(2000);
    digitalWrite(redLed, HIGH);
    delay(2000);
    digitalWrite(redLed, LOW);
    delay(2000);
    digitalWrite(redLed, HIGH);
  }
   resetlock();
}

void resetlock(){
  presscount = 0;
  if(digitalRead(redLed) == HIGH){
  Serial.println("TRY again");
  Serial.print("retries left : ");
  Serial.println(3 - tries);
  tries++;
  }

  if(tries > 3){
    Serial.println("LOCKED !");
    Serial.println("please contact our customer service for repair");
  while(true){delay(100);}
}
}

void waitforrelease(int button){
  delay(100);
  while(button == LOW){

  }
  delay(100);
}
